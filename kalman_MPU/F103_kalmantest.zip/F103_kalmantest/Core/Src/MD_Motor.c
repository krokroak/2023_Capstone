
void ALARM_RESET(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,10,1,8,125);
}
void TQ_CTRL(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,44,1,1,98);
}
void TQ_OFF(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,5,1,1,137);
}
void BRAKE(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,6,1,1,136);
}
void Torque_Control_CW(int A){//0.1A ?  ?
	if (A==0){
		TQ_OFF();
	}
	else if(A<151){
      printf("%c%c%c%c%c%c%c%c\r\n",183,184,1,140,2,A,0,258-A);
   }
}
void Torque_Control_CCW(int A){//0.1A ?  ?
	if (A==0){
		TQ_OFF();
	}
	else if(A<151){
      printf("%c%c%c%c%c%c%c%c\r\n",183,184,1,140,2,256-A,255,A+3);
    }
}
//if(IC >= 0){
//   s_flag=0;
//   Torque_Control_CW(IC);
//
//}
//else if(IC < 0){
//   Torque_Control_CCW(IC*-1);
//}
