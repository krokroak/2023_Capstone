
#include "stm32l4xx_hal.h"

void ALARM_RESET(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 10;
	tx_send[4] = 1;
	tx_send[5] = 8;
	tx_send[6] = 125;
	tx_send[7] = '\r';
	tx_send[8] = '\n';
	HAL_UART_Transmit(huart,&tx_send,9,100);
}
void TQ_CTRL(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 44;
	tx_send[4] = 1;
	tx_send[5] = 1;
	tx_send[6] = 98;
	tx_send[7] = '\r';
	tx_send[8] = '\n';
	HAL_UART_Transmit(huart,&tx_send,9,100);

}
void Vel_CTRL(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 44;
	tx_send[4] = 1;
	tx_send[5] = 0;
	tx_send[6] = 99;
	tx_send[7] = '\r';
	tx_send[8] = '\n';
	HAL_UART_Transmit(huart,&tx_send,9,100);
}
void TQ_OFF(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 5;
	tx_send[4] = 1;
	tx_send[5] = 1;
	tx_send[6] = 137;
	tx_send[7] = '\r';
	tx_send[8] = '\n';
	HAL_UART_Transmit(huart,&tx_send,9,100);

}
void BRAKE(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 6;
	tx_send[4] = 1;
	tx_send[5] = 1;
	tx_send[6] = 136;
	tx_send[7] = '\r';
	tx_send[8] = '\n';
	HAL_UART_Transmit(huart,&tx_send,9,100);
}
void Torque_Control_CW(int A,UART_HandleTypeDef *huart){//0.1A ?  ?
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 140;
	tx_send[4] = 2;
	tx_send[5] = A;
	tx_send[6] = 0;
	tx_send[7] = 258-A;
	tx_send[8] = '\r';
	tx_send[9] = '\n';
	if(A<201){
      HAL_UART_Transmit(huart,&tx_send,10,100);
   }
}
void Change_Brake(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 24;
	tx_send[4] = 1;
	tx_send[5] = 3;
	tx_send[6] = 116;
	tx_send[7] = '\r';
	tx_send[8] = '\n';
	HAL_UART_Transmit(huart,&tx_send,9,100);

}
void Torque_Control_CCW(int A){//0.1A ?  ?}
	if(A<201){
      printf("%c%c%c%c%c%c%c%c\r\n",183,184,1,140,2,256-A,255,A+3);
    }
}
void ENC_PPR(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 156;
	tx_send[4] = 2;
	tx_send[5] = 0;
	tx_send[6] = 64;
	tx_send[7] = 178;
	tx_send[8] = '\r';
	tx_send[9] = '\n';
}
void USE_ENC_Phase(UART_HandleTypeDef *huart){
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 71;
	tx_send[4] = 1;
	tx_send[5] = 1;
	tx_send[6] = 71;
	tx_send[7] = '\r';
	tx_send[8] = '\n';
	printf("%c%c%c%c%c%c%c\r\n",183,184,1,71,1,1,71);
}
void Vel_Control(int A,UART_HandleTypeDef *huart){
	int high = 0;
	int low = 0;
	if(A<0){
		low = -A;
	}
	else{
		low = A;
	}//                      16 8 4 2 1     4096 2048 1024 512 256
	if(low>=4096){
		low = low-4096;
		high  = high + 16;
	}
	if(low>=2048){
		low = low-2048;
		high  = high + 8;
	}
	if(low>=1024){
		low = low-1024;
		high  = high + 4;
	}
	if(low>=512){
		low = low-512;
		high  = high + 2;
	}
	if(low>=256){
		low = low-256;
		high  = high + 1;
	}
	if(A<0){
		high = 255 - high;
		low = 256 - low;
		if(low == 256){
			low = 0;
			high = high + 1;
		}
	}
	int check_sum = 256-((500+low+high)%256);
	if(check_sum == 256){
		check_sum = 0;
	}
	uint8_t tx_send[10];
	tx_send[0] = 183;
	tx_send[1] = 184;
	tx_send[2] = 1;
	tx_send[3] = 130;
	tx_send[4] = 2;
	tx_send[5] = low;
	tx_send[6] = high;
	tx_send[7] = check_sum;
	tx_send[8] = '\r';
	tx_send[9] = '\n';
	HAL_UART_Transmit(huart,tx_send,10,1);

}
//if(IC >= 0){
//   s_flag=0;
//   Torque_Control_CW(IC);
//
//}
//else if(IC < 0){
//   Torque_Control_CCW(IC*-1);
//}
