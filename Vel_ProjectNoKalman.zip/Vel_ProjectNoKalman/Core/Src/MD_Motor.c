
void ALARM_RESET(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,10,1,8,125);
}
void TQ_CTRL(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,44,1,1,98);
}
void Vel_CTRL(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,44,1,0,99);
}
void TQ_OFF(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,5,1,1,137);
}
void BRAKE(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,6,1,1,136);
}
void Torque_Control_CW(int A){//0.1A ?  ?
   if(A<201){
      printf("%c%c%c%c%c%c%c%c\r\n",183,184,1,140,2,A,0,258-A);
   }
}
void Inverse_Motor(){
	printf("%c%c%c%c%c%c%c\r\n",183,184,1,16,1,1,126);
}

void Change_Brake(void){
   printf("%c%c%c%c%c%c%c\r\n",183,184,1,24,1,3,116);
}
void Torque_Control_CCW(int A){//0.1A ?  ?}
	if(A<201){
      printf("%c%c%c%c%c%c%c%c\r\n",183,184,1,140,2,256-A,255,A+3);
    }
}
void ENC_PPR(){
	printf("%c%c%c%c%c%c%c%c\r\n",183,184,1,156,2,0,64,178);
}
void USE_ENC_Phase(){
	printf("%c%c%c%c%c%c%c\r\n",183,184,1,71,1,1,71);
}
void Vel_Control(int A){
	int high = 0;
	int low = 0;
	if(A<0){
		low = -A;
	}
	else{
		low = A;
	}//                      16 8 4 2 1     4096 2048 1024 512 256
	if(low>=4096){
		low = low-4096;
		high  = high + 16;
	}
	if(low>=2048){
		low = low-2048;
		high  = high + 8;
	}
	if(low>=1024){
		low = low-1024;
		high  = high + 4;
	}
	if(low>=512){
		low = low-512;
		high  = high + 2;
	}
	if(low>=256){
		low = low-256;
		high  = high + 1;
	}
	if(A<0){
		high = 255 - high;
		low = 256 - low;
		if(low == 256){
			low = 0;
			high = high + 1;
		}
	}
	int check_sum = 256-((500+low+high)%256);
	if(check_sum == 256){
		check_sum = 0;
	}
	printf("%c%c%c%c%c%c%c%c\r\n",183,184,1,130,2,low,high,check_sum);

}
//if(IC >= 0){
//   s_flag=0;
//   Torque_Control_CW(IC);
//
//}
//else if(IC < 0){
//   Torque_Control_CCW(IC*-1);
//}
